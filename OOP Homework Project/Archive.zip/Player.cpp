#include "Player.h"
#include "Shop.h"
#include "Creature.h"
#include <iostream>
using namespace std;

Player::Player(string PlayerName)
{
    this->name = PlayerName;
}
void Player::SetName(string name)
{
    this->name = name;
}
string Player::GetName()
{
    return this->name;
}
int Player::GetGold()
{
    return this->gold;
}
void Player::Buy(Shop* &shop, Creature* type, int count)
{
    shop->Buy(type, this->playerUnits, this->gold, count);
}
void Player::SetPlayerUnits(vector< pair<Creature*, int> > playerUnits)
{
    this->playerUnits = playerUnits;
}
vector< pair<Creature*, int> > Player::GetUnits()
{
    return this->playerUnits;
}