#include "Game.h"
#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include "Battlefield.h"
#include <string>
#include <vector>
#include <map>
using namespace std;

bool BestPosition(Battlefield* &field, int &sRow, int &sCol, int &dRow, int &dCol);

Game::Game()
{
    m_player = new Player("Player");
    m_enemy = new Player("Enemy");
}

void Game::PrintUnitsPrice(Shop* &shop)
{
    for (map<string,int>::iterator it = shop->Units().begin(); it != shop->Units().end(); ++it)
    {
        cout << it->first << " => " << it->second << '\n';
    }
}

void Game::BaseMenu(string command)
{
    if(command == "start game")
    {
        GameMenu();
    }
    else if (command == "go in shop")
    {
        cout<<"Name: "<<endl;
        string player;
        getline(cin, player);
        ShopMenu(player);
    }
    else if(command == "out")
    {
        
    }
    
//    StartGame();
  //  Menu();
//    QuitGame();
}
//void Game::ShopMenu(Player* &player)
void Game::ShopMenu(string name)
{
    cout<<name<<" is in shop"<<endl;
    
    Player* player;
    if (name == m_player->GetName())
    {
        player = m_player;
    }
    else if (name == m_enemy->GetName())
    {
        player = m_enemy;
    }
    
    Shop* shop = new Shop();
    string input;
    int count;
    while (true)
    {
        cout<<"Command for shop:"<<endl;
        getline(cin, input);
        if (input[0] == 'b')
        {
            switch (input[6])
            {
                case 'a'://peasant
                    count = stoi(input.substr(11));
                    player->Buy(shop, new Peasant(), count);
                    break;
                case 'c'://archer
                    count = stoi(input.substr(10));
                    player->Buy(shop, new Archer(), count);
                    break;
                case 'o'://footman
                    count = stoi(input.substr(11));
                    player->Buy(shop, new Footman(), count);
                    break;
                case 'i'://grifon
                    count = stoi(input.substr(11));
                    player->Buy(shop, new Griffon(), count);
                    break;
                default:
                    break;
            }
        }
        else if (input[0] == 'u')
        {
            PrintUnitsPrice(shop);
        }
        else if (input[0] == 'g')
        {
            cout<<player->GetGold()<<endl;
        }
        else break;
    }
}
void Game::GameMenu()
{
    string input;
    Battlefield* field = new Battlefield(m_player,m_enemy);
    
    int sRow;
    int sCol;
    int dRow;
    int dCol;
    int percent = 100;
    
    while (true)
    {
        cout<<"Command for game:"<<endl;
        getline(cin, input);
        if (input[1] == 'o')//move
        {
            sRow = (input[6] - '0');
            sCol = (input[8] - '0');
            dRow = (input[12] - '0');
            dCol = (input[14] - '0');
            
            if (input.size() > 16 && input[17] == '%')
            {
                percent = stoi(input.substr(18));
            }
            
            field->Move(sRow, sCol, dRow, dCol, percent);
            
        }
        else if (input[1] == 't')//atack
        {
            sRow = (input[8] - '0');
            sCol = (input[10] - '0');
            dRow = (input[14] - '0');
            dCol = (input[16] - '0');
            
//            cout<<input[8]<<endl;
//            cout<<input[10]<<endl;
//            cout<<input[14]<<endl;
//            cout<<input[16]<<endl;
//            cout<<sRow<<endl;
//            cout<<sCol<<endl;
//            cout<<dRow<<endl;
//            cout<<dCol<<endl;
            
            
            if (input[19] == '%')
            {
                percent = stoi(input.substr(20));
            }
            
            field->Atack(sRow, sCol, dRow, dCol);
            
        }
        else if (input[0] == 'p') //print
        {
            string fileName = "output.txt";
            field->Print(fileName);
        }
        else if (input[0] == 's')
        {
            break;
        }
        else
            cout<<"error command"<<endl;
    }
}


//bool BestPosition(Battlefield* &field, int &sRow, int &sCol, int &dRow, int &dCol)
//{
//    int fRow = dRow;
//    int fCol = dCol;
//    int stamina = field->GetCreature(dRow, dCol)->GetStamina();
//    
//    int distance = 100;
//    
////    int lRow = 0;
////    int lCol = 0;
//    
////    dRow = fRow - 1;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow - 1;
////    dCol = fCol ;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow - 1;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol + 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow + 1;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    dRow = fRow;
////    dCol = fCol - 1;
////    if (dRow > 0 && dRow < 10 && dCol > 0 && dCol < 10)
////    {
////        if (field->IsFree(dRow, dCol))
////        {
////            if (distance > field->Distance(sRow, sCol, dRow, dCol))
////            {
////                distance = field->Distance(sRow, sCol, dRow, dCol);
////                check = true;
////                lRow = dRow;
////                lCol = dCol;
////            }
////        }
////    }
////    
////    dRow = lRow;
////    dCol = lCol;
//    
//    bool check = false;
//    
//    for (int row = fRow - stamina; row < fRow + stamina; row++)
//    {
//        if (row >= 0 && row < 10)
//        {
//            for (int col = fCol - stamina; col < fCol + stamina; col++)
//            {
//                if (col >= 0 && col < 10 && !(col == fCol && row == fRow))
//                {
//                    if( field->IsFree(row, col) && distance > field->Distance(sRow, sCol, dRow, dCol) )
//                    {
//                        distance = field->Distance(sRow, sCol, dRow, dCol);
//                        dRow = row;
//                        dCol = col;
//                        check = true;
//                    }
//                }
//            }
//        }
//    }
//    
//    if (!check)
//    {
//        cout<<"cant atack"<<endl;
//    }
//    
//    return check;
//}

