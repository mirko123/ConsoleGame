//
//  Battlefield.cpp
//  OOP Homework Project
//
//  Created by Мирослав Николов on 25.05.15.
//  Copyright (c) 2015 г. Мирослав Николов. All rights reserved.
//

#include "Battlefield.h"
#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include <string>
#include <vector>
#include <fstream>
#include <math.h>
#include <map>

Battlefield::Battlefield(Player* &player1, Player* &player2)
{
    this->player1 = player1;
    this->player2 = player2;
    for (int row = 0; row < 10; row++)
    {
        for (int col = 0; col < 10; col++)
        {
            matrix[row][col] = nullptr;
            mat[row][col] = 0;
            playerMat[row][col] = 0;
        }
        
        
        if(row < player1->GetUnits().size())
        {
            matrix[row][0] = player1->GetUnits()[row].first;
            mat[row][0] = player1->GetUnits()[row].second;
            playerMat[row][0] = 1;
        }
        if(row < player2->GetUnits().size())
        {
            matrix[row][9] = player2->GetUnits()[row].first;
            mat[row][9] = player2->GetUnits()[row].second;
            playerMat[row][9] = -1;
        }
    }
}

void Battlefield::SetCreature(Creature* &unit,int &count, int &row, int &col, string player)
{
    if ( IsFree(row, col))
    {
        matrix[row][col] = unit;
        mat[row][col] = count;
        if (player[0] == 'e')
        {
            playerMat[row][col] = -1;
        }
        else
        {
            playerMat[row][col] = 1;
        }
    }
    else
    {
        cout<<"this position is occupied"<<endl;
    }
}
Creature* Battlefield::GetCreature(int &row, int &col)
{
    if (IsFree(row, col))
    {
        return matrix[row][col];
    }
    return 0;
}

double Battlefield::Distance(int sRow, int sCol, int dRow, int dCol)
{
    return sqrt((dRow - sRow)*(dRow - sRow) + (dCol - sCol)*(dCol - sCol));;
}

bool Battlefield::CheckDistance(int &sRow, int &sCol, int &dRow, int &dCol)
{
    int distance = sqrt((dRow - sRow)*(dRow - sRow) + (dCol - sCol)*(dCol - sCol));
    if (distance > matrix[sRow][sCol]->GetStamina())
    {
        cout<<"Big distance"<<endl;
        return 0;
    }
    else return 1;
}

bool Battlefield::Move(int &sRow, int &sCol, int &dRow, int &dCol, int percent)
{
    cout<<"percent"<<percent<<endl;
    int willMove = mat[sRow][sCol] * (percent/100);
    int willStay = mat[sRow][sCol] - willMove;
    

    if (!CheckDistance(sRow, sCol, dRow, dCol))
    {
        cout<<"Big distance1"<<endl;
        return 0;
    }
    else if (!IsFree(dRow, dCol))
    {
        if(playerMat[sRow][sCol] == playerMat[dRow][dCol] &&
                matrix[sRow][sCol]->GetType() == matrix[dRow][dCol]->GetType())
        {
            matrix[dRow][dCol] = matrix[sRow][sCol];
            mat[dRow][dCol] = mat[sRow][sCol];
            playerMat[dRow][dCol] = playerMat[sRow][sCol];
            
            if (willStay == 0)
            {
                matrix[sRow][sCol] = nullptr;
                mat[dRow][dCol] += mat[sRow][sCol];
                mat[sRow][sCol] = 0;
                playerMat[sRow][sCol] = 0;
            }
            else
            {
                mat[sRow][sCol] = willStay;
                mat[dRow][dCol] += willMove;
            }
            return 1;
        }
        
        cout<<"error source position"<<endl;
        return 0;
    }
    else if (IsFree(dRow, dCol))
    {
        
        matrix[dRow][dCol] = matrix[sRow][sCol];
        mat[dRow][dCol] = mat[sRow][sCol];
        playerMat[dRow][dCol] = playerMat[sRow][sCol];
        
        if (willStay == 0)
        {
            matrix[sRow][sCol] = nullptr;
            mat[dRow][dCol] = mat[sRow][sCol];
            mat[sRow][sCol] = 0;
            playerMat[sRow][sCol] = 0;
        }
        else
        {
            mat[sRow][sCol] = willStay;
            mat[dRow][dCol] = willMove;
        }
        return 1;
    }
    else
    {
        cout<<"error destionation"<<endl;
        return 0;
    }
}

bool Battlefield::Atack(int &sRow, int &sCol, int &dRow, int &dCol, int percent)
{
    int fRow = dRow;
    int fCol = fCol;
    bool check = BestPosition(sRow, sCol, fRow, fCol);
    
    if(check)
    {
        if (this->CheckDistance(sRow, sCol, fRow, fCol))
        {
            if(this->Move(sRow, sCol, fRow, fCol, percent))
            {
                //......
                int aDmg = 0;
                int dCount = 0;
                
                int dDmg = 0;
                int aCount = 0;
                
                while (true)
                {
                    aDmg = this->matrix[fRow][fCol]->Attack(mat[fRow][fCol]);
                    dCount = this->matrix[dRow][dCol]->Defense(mat[dRow][dCol], aDmg);
                    
                    dDmg = this->matrix[dRow][dCol]->Attack(mat[dRow][dCol]);
                    aCount = this->matrix[fRow][fCol]->Defense(mat[fRow][fCol], dDmg);
                    
                    if (dCount == 0 && aCount == 0)
                    {
                        cout<<"2 lose"<<endl;
                        matrix[fRow][fCol] = nullptr;
                        mat[fRow][fCol] = 0;
                        playerMat[fRow][fCol] = 0;
                        
                        matrix[dRow][dCol] = nullptr;
                        mat[dRow][dCol] = 0;
                        playerMat[dRow][dCol] = 0;
                        break;
                    }
                    else if (aCount == 0)
                    {
                        cout<<playerMat[dRow][dCol]<<"Win"<<endl;
                        
                        matrix[fRow][fCol] = nullptr;
                        mat[fRow][fCol] = 0;
                        playerMat[fRow][fCol] = 0;
                        break;
                    }
                    else if (dCount == 0)
                    {
                        cout<<playerMat[fRow][fCol]<<"Win"<<endl;
                        
                        matrix[dRow][dCol] = nullptr;
                        mat[dRow][dCol] = 0;
                        playerMat[dRow][dCol] = 0;
                        break;
                    }
                }
                
                SetPlayerUnits();
                if (player1->GetUnits().size() == 0 && player2->GetUnits().size() == 0)
                {
                    cout<<"players 1 and 2 lose"<<endl;
                }
                else if (player1->GetUnits().size() == 0)
                {
                    cout<<"player 1 lose"<<endl;
                }
                else if (player2->GetUnits().size() == 0)
                {
                    cout<<"player 2 lose"<<endl;
                }
                
                return 1;
            }
            else
            {
                cout<<"Big distance2"<<endl;
            }
        }
        else
        {
            cout<<"Big distance3"<<endl;
        }
    }
    else
    {
        cout<<"zaeto e"<<endl;
    }
    return 0;
}

bool Battlefield::IsFree(int row, int col)
{
    if (matrix[row][col] == nullptr) {
        return true;
    }
    else return false;
}

void Battlefield::Print(string &fileName)
{
    string field;
    string value = "";
    string prefix;
    
    map<string, int> map;

    for (int row = 0; row < 10; row++)
    {
        for (int col = 0; col < 10; col++)
        {
            value = to_string(mat[row][col]);
            if (mat[row][col] != 0)
            {
                value = value + matrix[row][col]->GetType()[0];
                
                if (playerMat[row][col] == -1)
                {
                    value = 'E' + value;
                    prefix = "E" + string(&matrix[row][col]->GetType()[0]);
                    map[prefix]+=mat[row][col];
                }
                else if (playerMat[row][col] == 1)
                {
                    value = 'M' + value;
                    prefix = "M" + string(&matrix[row][col]->GetType()[0]);
                    map[prefix]+=mat[row][col];
                }
            }
            
            for (int i = 0; i < 15 - value.length(); i++) {
                value += " ";
            }
            field = field + value;
        }
        field+='\n';
    }
    
    for(auto it = map.begin(); it != map.cend(); ++it)
    {
        field = field + it->first + "-" + to_string(it->second) + " ";
    }
    
    ofstream outfile (fileName);
    outfile << field << endl;
    outfile.close();
}

void Battlefield::SetPlayerUnits()
{
    vector< pair<Creature*, int> > playerUnits1;
    vector< pair<Creature*, int> > playerUnits2;
    
    for (int row = 0; row < 10; row++)
    {
        for (int col = 0; col < 10; col++)
        {
            if (playerMat[row][col] == 1)
            {
                for (int i = 0; i < playerUnits1.size(); i++)
                {
                    if (playerUnits1[i].first->GetType() == matrix[row][col]->GetType())
                    {
                        playerUnits1[i].second++;
                    }
                    else if ( i == playerUnits1.size() - 1)
                    {
                        playerUnits1[i].first = matrix[row][col];
                        playerUnits1[i].second = 0;
                    }
                }
            }
            
            
            else if (playerMat[row][col] == -1)
            {
                for (int i = 0; i < playerUnits2.size(); i++)
                {
                    if (playerUnits2[i].first->GetType() == matrix[row][col]->GetType())
                    {
                        playerUnits2[i].second++;
                    }
                    else if ( i == playerUnits1.size() - 1)
                    {
                        playerUnits2[i].first = matrix[row][col];
                        playerUnits2[i].second = 0;
                    }
                }
                
                
                
            }
        }
    }
    
    
    player1->SetPlayerUnits(playerUnits1);
    player2->SetPlayerUnits(playerUnits2);
}

bool Battlefield::BestPosition(int &sRow, int &sCol, int &dRow, int &dCol)
{
    int fRow = dRow;
    int fCol = dCol;
    int stamina = this->GetCreature(dRow, dCol)->GetStamina();
    
    int distance = 100;
    
    bool check = false;
    
    for (int row = fRow - stamina; row < fRow + stamina; row++)
    {
        if (row >= 0 && row < 10)
        {
            for (int col = fCol - stamina; col < fCol + stamina; col++)
            {
                if (col >= 0 && col < 10 && !(col == fCol && row == fRow))
                {
                    if( this->IsFree(row, col) && distance > this->Distance(sRow, sCol, dRow, dCol) )
                    {
                        distance = this->Distance(sRow, sCol, dRow, dCol);
                        dRow = row;
                        dCol = col;
                        check = true;
                    }
                }
            }
        }
    }
    
    if (!check)
    {
        cout<<"cant atack"<<endl;
    }
    
    return check;
}




