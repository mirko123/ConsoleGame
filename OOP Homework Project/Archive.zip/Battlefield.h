//
//  Battlefield.h
//  OOP Homework Project
//
//  Created by Мирослав Николов on 25.05.15.
//  Copyright (c) 2015 г. Мирослав Николов. All rights reserved.
//

#ifndef __OOP_Homework_Project__Battlefield__
#define __OOP_Homework_Project__Battlefield__

#include <iostream>
#include "Creature.h"
#include "Player.h"
#include "Shop.h"
#include "Game.h"
#include "Player.h"
#include <string>
#include <vector>
#include <map>

class Battlefield
{
private:
    Player* player1;
    Player* player2;
    Creature* matrix[10][10];
    int mat[10][10]; //count units
    int playerMat[10][10]; // не очаквах да са толкова много параметри и заради това не съм използвал вектор
    bool BestPosition(int &sRow, int &sCol, int &dRow, int &dCol);
    void SetPlayerUnits();
public:
    Battlefield(Player* &player1, Player* &player2);
    bool IsFree(int row, int col);
    void SetCreature(Creature* &unit, int &count, int &row, int &col, string player = " ");
    Creature* GetCreature(int &row, int &col);
    bool Move(int &sRow, int &sCol, int &dRow, int &dCol, int percent = 100);
    bool Atack(int &sRow, int &sCol, int &dRow, int &dCol, int percent = 100);
    void Print(string &fileName);
    static double Distance(int sRow, int sCol, int dRow, int dCol);
    bool CheckDistance(int &sRow, int &sCol, int &dRow, int &dCol);
};

#endif /* defined(__OOP_Homework_Project__Battlefield__) */
